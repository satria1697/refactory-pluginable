var s="assets/ArrowRight.96489501.svg";export{s as _};
